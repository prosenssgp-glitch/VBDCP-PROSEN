package com.vbdcp.attendance;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.media.MediaScannerConnection;
import android.os.Environment;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.util.Base64;
import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;
import android.webkit.*;
import android.view.*;
import java.io.*;
import androidx.core.content.FileProvider;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> uploadCallback;
    private Uri cameraUri;
    private static final int FILE_CHOOSER = 1001;
    private static final int CAMERA_CAPTURE = 1002;
    private static final int WRITE_STORAGE = 1003;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.CAMERA"}, CAMERA_CAPTURE);
        } else if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, WRITE_STORAGE);
        }
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new CameraBridge(), "VBDCPNativeCamera");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(uploadCallback!=null) uploadCallback.onReceiveValue(null);
                uploadCallback=cb;
                boolean imageOnly=true;
                if(params.getAcceptTypes()!=null){
                    for(String a:params.getAcceptTypes()) if(a!=null && !a.isEmpty() && !a.startsWith("image/")) imageOnly=false;
                }
                if(imageOnly){
                    try{
                        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, WRITE_STORAGE);
                            if(uploadCallback!=null) uploadCallback.onReceiveValue(null);
                            uploadCallback=null;
                            return true;
                        }
                        File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"VBDCP"); dir.mkdirs();
                        File f=File.createTempFile("VBDCP_", ".jpg", dir);
                        cameraUri=FileProvider.getUriForFile(MainActivity.this,"com.vbdcp.attendance.fileprovider",f);
                        Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        i.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        startActivityForResult(i,CAMERA_CAPTURE); return true;
                    }catch(Exception e){ }
                }
                try{ Intent i=new Intent(Intent.ACTION_GET_CONTENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); startActivityForResult(Intent.createChooser(i,"Select image"),FILE_CHOOSER); return true; }
                catch(Exception e){ uploadCallback=null; cb.onReceiveValue(null); return false; }
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("https://tranquil-cupcake-5491f0.netlify.app/");
    }
    private class CameraBridge {
        @android.webkit.JavascriptInterface
        public String saveImageBase64(String dataUrl, String fileName) {
            try {
                if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) return "";
                String base64=dataUrl;
                int comma=base64.indexOf(',');
                if(comma>=0) base64=base64.substring(comma+1);
                byte[] bytes=Base64.decode(base64, Base64.DEFAULT);
                String safe=(fileName==null||fileName.trim().isEmpty()?"VBDCP_"+System.currentTimeMillis()+".jpg":fileName.replaceAll("[^A-Za-z0-9_.-]","_"));
                if(!safe.toLowerCase().endsWith(".jpg")) safe += ".jpg";
                Uri uri;
                if(Build.VERSION.SDK_INT>=29){
                    ContentValues v=new ContentValues();
                    v.put(MediaStore.Images.Media.DISPLAY_NAME,safe);
                    v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
                    v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/VBDCP");
                    v.put(MediaStore.Images.Media.IS_PENDING,1);
                    uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
                    if(uri==null) return "";
                    try(OutputStream os=getContentResolver().openOutputStream(uri)){ os.write(bytes); }
                    v.clear(); v.put(MediaStore.Images.Media.IS_PENDING,0);
                    getContentResolver().update(uri,v,null,null);
                }else{
                    File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),"VBDCP");
                    if(!dir.exists() && !dir.mkdirs()) return "";
                    File f=new File(dir,safe);
                    try(FileOutputStream fos=new FileOutputStream(f)){fos.write(bytes);}
                    MediaScannerConnection.scanFile(MainActivity.this,new String[]{f.getAbsolutePath()},new String[]{"image/jpeg"},null);
                    uri=FileProvider.getUriForFile(MainActivity.this,"com.vbdcp.attendance.fileprovider",f);
                }
                return uri.toString();
            }catch(Exception e){ return ""; }
        }
        @android.webkit.JavascriptInterface
        public void shareImages(String jsonUris) {
            try {
                JSONArray a=new JSONArray(jsonUris);
                ArrayList<Uri> uris=new ArrayList<>();
                for(int i=0;i<a.length();i++){String u=a.optString(i);if(!u.isEmpty())uris.add(Uri.parse(u));}
                if(uris.isEmpty()) return;
                Intent share=new Intent(Intent.ACTION_SEND_MULTIPLE);
                share.setType("image/jpeg");
                share.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris);
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                runOnUiThread(() -> startActivity(Intent.createChooser(share,"VBDCP ছবি Share করুন")));
            }catch(Exception ignored){}
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data){
        super.onActivityResult(request,result,data);
        if(uploadCallback==null) return;
        Uri[] resultUris=null;
        if(result==RESULT_OK){
            if(request==CAMERA_CAPTURE && cameraUri!=null) resultUris=new Uri[]{cameraUri};
            else if(data!=null){
                if(data.getClipData()!=null){ int n=data.getClipData().getItemCount(); resultUris=new Uri[n]; for(int i=0;i<n;i++) resultUris[i]=data.getClipData().getItemAt(i).getUri(); }
                else if(data.getData()!=null) resultUris=new Uri[]{data.getData()};
            }
        }
        uploadCallback.onReceiveValue(resultUris); uploadCallback=null; cameraUri=null;
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
